package com.furuan.clicker

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var word: EditText
    private lateinit var textMs: EditText
    private lateinit var clickX: EditText
    private lateinit var clickY: EditText
    private lateinit var clickMs: EditText

    private fun field(hintText: String, value: String) = EditText(this).apply {
        hint = hintText; setText(value); textSize = 16f; setSingleLine(true)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(24, 24, 24, 24)
            setBackgroundColor(0xFF101218.toInt())
        }
        fun label(s: String) {
            root.addView(TextView(this).apply {
                text = s; textSize = 15f; setTextColor(0xFFECEFF4.toInt()); setPadding(0, 10, 0, 2)
            })
        }
        root.addView(TextView(this).apply {
            text = "服软定制连点器"; textSize = 25f; setTextColor(0xFFFFFFFF.toInt()); setPadding(0, 0, 0, 12)
        })
        label("重复文字（尝试覆盖当前聚焦的输入框）")
        word = field("要重复的文字", "🆔微微一笑"); root.addView(word, ViewGroup.LayoutParams(-1, -2))
        textMs = field("文字更新间隔（毫秒）", "1000"); root.addView(textMs, ViewGroup.LayoutParams(-1, -2))
        label("连点坐标（屏幕左上角为 0,0）")
        clickX = field("X 坐标", "500"); root.addView(clickX, ViewGroup.LayoutParams(-1, -2))
        clickY = field("Y 坐标", "900"); root.addView(clickY, ViewGroup.LayoutParams(-1, -2))
        clickMs = field("点击间隔（毫秒，系统可能限制速度）", "100"); root.addView(clickMs, ViewGroup.LayoutParams(-1, -2))
        root.addView(Button(this).apply {
            text = "① 开启辅助功能权限"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }, ViewGroup.LayoutParams(-1, -2))
        root.addView(Button(this).apply {
            text = "② 开启悬浮控制"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                    return@setOnClickListener
                }
                getSharedPreferences("cfg", MODE_PRIVATE).edit()
                    .putString("word", word.text.toString())
                    .putLong("textMs", textMs.text.toString().toLongOrNull()?.coerceAtLeast(100) ?: 1000)
                    .putInt("x", clickX.text.toString().toIntOrNull() ?: 500)
                    .putInt("y", clickY.text.toString().toIntOrNull() ?: 900)
                    .putLong("clickMs", clickMs.text.toString().toLongOrNull()?.coerceAtLeast(1) ?: 100)
                    .apply()
                startService(Intent(this@MainActivity, FloatingService::class.java))
                Toast.makeText(this@MainActivity, "悬浮控制已启动；请切换到目标应用并聚焦输入框", Toast.LENGTH_LONG).show()
            }
        }, ViewGroup.LayoutParams(-1, -2))
        label("提示：先在目标应用点进输入框。不同应用可能不允许辅助服务改写内容。")
        setContentView(root)
    }
}
