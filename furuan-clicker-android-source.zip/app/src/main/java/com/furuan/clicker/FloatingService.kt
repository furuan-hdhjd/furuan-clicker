package com.furuan.clicker

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Toast

class FloatingService : Service() {
    private lateinit var wm: WindowManager
    private var panel: LinearLayout? = null
    private val handler = Handler(Looper.getMainLooper())
    private var running = true
    private var clickRunning = false
    private var textRunning = false

    private val clickTask = object : Runnable {
        override fun run() {
            if (!running || !clickRunning) return
            val p = getSharedPreferences("cfg", MODE_PRIVATE)
            ClickAccessibilityService.instance?.clickAt(p.getInt("x", 500), p.getInt("y", 900))
            handler.postDelayed(this, p.getLong("clickMs", 100).coerceAtLeast(1))
        }
    }
    private val textTask = object : Runnable {
        override fun run() {
            if (!running || !textRunning) return
            val p = getSharedPreferences("cfg", MODE_PRIVATE)
            ClickAccessibilityService.instance?.replaceFocusedText(p.getString("word", "") ?: "")
            handler.postDelayed(this, p.getLong("textMs", 1000).coerceAtLeast(100))
        }
    }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(8, 8, 8, 8); setBackgroundColor(0xEE20232A.toInt())
        }
        fun addButton(title: String, action: () -> Unit) {
            box.addView(Button(this).apply { text = title; setOnClickListener { action() } })
        }
        addButton("开始/暂停连点") {
            clickRunning = !clickRunning
            if (clickRunning) handler.post(clickTask) else handler.removeCallbacks(clickTask)
            Toast.makeText(this, if (clickRunning) "连点已开始" else "连点已暂停", Toast.LENGTH_SHORT).show()
        }
        addButton("开始/暂停文字覆盖") {
            textRunning = !textRunning
            if (textRunning) handler.post(textTask) else handler.removeCallbacks(textTask)
            Toast.makeText(this, if (textRunning) "文字更新已开始" else "文字更新已暂停", Toast.LENGTH_SHORT).show()
        }
        addButton("停止并关闭悬浮窗") { stopSelf() }
        panel = box
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 12; y = 150 }
        wm.addView(box, params)
    }
    override fun onDestroy() {
        running = false; clickRunning = false; textRunning = false
        handler.removeCallbacksAndMessages(null)
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null; super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
