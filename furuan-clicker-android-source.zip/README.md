# 服软定制连点器 Android 源码

通过 GitHub Actions 自动构建 debug APK。

## 使用限制
- 需要在 Android 系统设置中手动启用辅助功能和悬浮窗权限。
- 文字功能尝试对当前聚焦的可编辑控件执行 `ACTION_SET_TEXT`，不是所有应用都允许。
- 点击间隔是请求间隔，不保证 1ms 实际点击速度；Android 无障碍手势和系统调度会限制速度。
- 仅用于自己有权操作的应用和界面。

## 构建
在 GitHub Actions 中运行 `Build FuRuan APK`，完成后下载名为 `furuan-clicker-apk` 的 Artifact。
